#pragma once

namespace Lab1KarlMartin1015920 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;

	/// <summary>
	/// Resumen de MyForm
	/// </summary>
	public ref class MyForm : public System::Windows::Forms::Form
	{

	public:
		MyForm(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~MyForm()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::NumericUpDown^ txtoperador1;


	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Label^ label2;
	private: System::Windows::Forms::NumericUpDown^ txtoperador2;
	private: System::Windows::Forms::Label^ lblresultado;
	private: System::Windows::Forms::Label^ label3;
	private: System::Windows::Forms::Button^ button2;

	protected:

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container^ components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->txtoperador1 = (gcnew System::Windows::Forms::NumericUpDown());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->label2 = (gcnew System::Windows::Forms::Label());
			this->txtoperador2 = (gcnew System::Windows::Forms::NumericUpDown());
			this->lblresultado = (gcnew System::Windows::Forms::Label());
			this->label3 = (gcnew System::Windows::Forms::Label());
			this->button2 = (gcnew System::Windows::Forms::Button());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtoperador1))->BeginInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtoperador2))->BeginInit();
			this->SuspendLayout();
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(12, 34);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(53, 13);
			this->label1->TabIndex = 0;
			this->label1->Text = L"N�mero 1";
			// 
			// txtoperador1
			// 
			this->txtoperador1->Location = System::Drawing::Point(84, 34);
			this->txtoperador1->Name = L"txtoperador1";
			this->txtoperador1->Size = System::Drawing::Size(120, 20);
			this->txtoperador1->TabIndex = 1;
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(22, 150);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(128, 23);
			this->button1->TabIndex = 3;
			this->button1->Text = L"Multiplicar - Iterativo";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &MyForm::button1_Click);
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(12, 68);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(53, 13);
			this->label2->TabIndex = 4;
			this->label2->Text = L"Numero 2";
			// 
			// txtoperador2
			// 
			this->txtoperador2->Location = System::Drawing::Point(84, 61);
			this->txtoperador2->Name = L"txtoperador2";
			this->txtoperador2->Size = System::Drawing::Size(120, 20);
			this->txtoperador2->TabIndex = 5;
			// 
			// lblresultado
			// 
			this->lblresultado->AutoSize = true;
			this->lblresultado->Location = System::Drawing::Point(84, 100);
			this->lblresultado->Name = L"lblresultado";
			this->lblresultado->Size = System::Drawing::Size(13, 13);
			this->lblresultado->TabIndex = 6;
			this->lblresultado->Text = L"0";
			// 
			// label3
			// 
			this->label3->AutoSize = true;
			this->label3->Location = System::Drawing::Point(15, 100);
			this->label3->Name = L"label3";
			this->label3->Size = System::Drawing::Size(53, 13);
			this->label3->TabIndex = 7;
			this->label3->Text = L"Producto:";
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(22, 180);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(128, 23);
			this->button2->TabIndex = 8;
			this->button2->Text = L"Multiplicar - Recursivo";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &MyForm::button2_Click);
			// 
			// MyForm
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(309, 261);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->label3);
			this->Controls->Add(this->lblresultado);
			this->Controls->Add(this->txtoperador2);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->button1);
			this->Controls->Add(this->txtoperador1);
			this->Controls->Add(this->label1);
			this->Name = L"MyForm";
			this->Text = L"MyForm";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtoperador1))->EndInit();
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->txtoperador2))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		
		int m(int valor1, int valor2) {
			if (valor1 < valor2) {
				m(valor2, valor1);
			}
			if (valor2 == 1) {
				return valor1;
			}
			else {
				return valor1 + m(valor1, valor2 - 1);
			}
		}
	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		int product = 0;
		int valor1 = (int)txtoperador1->Value;
		int valor2 = (int)txtoperador2->Value;
		for (int i = 1; i <= valor2; i++) {
			product = product + valor1;
		}
		lblresultado->Text = "" + product;
	}


	private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {


		lblresultado->Text = Convert::ToString(m(Convert::ToInt32(txtoperador1->Value), Convert::ToInt32(txtoperador2->Value)));






			
	}
	
};
}
