#pragma once

namespace Lab1KarlMartin1015920 {

	using namespace System;
	using namespace System::ComponentModel;
	using namespace System::Collections;
	using namespace System::Windows::Forms;
	using namespace System::Data;
	using namespace System::Drawing;
	using namespace System::IO;
	/// <summary>
	/// Resumen de Ejercicio2
	/// </summary>
	public ref class Ejercicio2 : public System::Windows::Forms::Form
	{
	public:
		Ejercicio2(void)
		{
			InitializeComponent();
			//
			//TODO: agregar c�digo de constructor aqu�
			//
		}

	protected:
		/// <summary>
		/// Limpiar los recursos que se est�n usando.
		/// </summary>
		~Ejercicio2()
		{
			if (components)
			{
				delete components;
			}
		}
	private: System::Windows::Forms::OpenFileDialog^ openFileDialog1;
	protected:
	private: System::Windows::Forms::SaveFileDialog^ saveFileDialog1;
	private: System::Windows::Forms::Button^ button1;
	private: System::Windows::Forms::Button^ button2;
	private: System::Windows::Forms::Button^ button3;
	private: System::Windows::Forms::DataGridView^ dataGridView1;
	private: System::Windows::Forms::Label^ label1;
	private: System::Windows::Forms::Label^ label2;

	private:
		/// <summary>
		/// Variable del dise�ador necesaria.
		/// </summary>
		System::ComponentModel::Container ^components;

#pragma region Windows Form Designer generated code
		/// <summary>
		/// M�todo necesario para admitir el Dise�ador. No se puede modificar
		/// el contenido de este m�todo con el editor de c�digo.
		/// </summary>
		void InitializeComponent(void)
		{
			this->openFileDialog1 = (gcnew System::Windows::Forms::OpenFileDialog());
			this->saveFileDialog1 = (gcnew System::Windows::Forms::SaveFileDialog());
			this->button1 = (gcnew System::Windows::Forms::Button());
			this->button2 = (gcnew System::Windows::Forms::Button());
			this->button3 = (gcnew System::Windows::Forms::Button());
			this->dataGridView1 = (gcnew System::Windows::Forms::DataGridView());
			this->label1 = (gcnew System::Windows::Forms::Label());
			this->label2 = (gcnew System::Windows::Forms::Label());
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->BeginInit();
			this->SuspendLayout();
			// 
			// openFileDialog1
			// 
			this->openFileDialog1->FileName = L"openFileDialog1";
			// 
			// button1
			// 
			this->button1->Location = System::Drawing::Point(6, 49);
			this->button1->Name = L"button1";
			this->button1->Size = System::Drawing::Size(75, 23);
			this->button1->TabIndex = 0;
			this->button1->Text = L"importar";
			this->button1->UseVisualStyleBackColor = true;
			this->button1->Click += gcnew System::EventHandler(this, &Ejercicio2::button1_Click);
			// 
			// button2
			// 
			this->button2->Location = System::Drawing::Point(208, 129);
			this->button2->Name = L"button2";
			this->button2->Size = System::Drawing::Size(75, 23);
			this->button2->TabIndex = 1;
			this->button2->Text = L"iterativo";
			this->button2->UseVisualStyleBackColor = true;
			this->button2->Click += gcnew System::EventHandler(this, &Ejercicio2::button2_Click);
			// 
			// button3
			// 
			this->button3->Location = System::Drawing::Point(43, 129);
			this->button3->Name = L"button3";
			this->button3->Size = System::Drawing::Size(75, 23);
			this->button3->TabIndex = 2;
			this->button3->Text = L"recursivo";
			this->button3->UseVisualStyleBackColor = true;
			this->button3->Click += gcnew System::EventHandler(this, &Ejercicio2::button3_Click);
			// 
			// dataGridView1
			// 
			this->dataGridView1->ColumnHeadersHeightSizeMode = System::Windows::Forms::DataGridViewColumnHeadersHeightSizeMode::AutoSize;
			this->dataGridView1->Location = System::Drawing::Point(43, 171);
			this->dataGridView1->Name = L"dataGridView1";
			this->dataGridView1->Size = System::Drawing::Size(240, 150);
			this->dataGridView1->TabIndex = 3;
			// 
			// label1
			// 
			this->label1->AutoSize = true;
			this->label1->Location = System::Drawing::Point(40, 338);
			this->label1->Name = L"label1";
			this->label1->Size = System::Drawing::Size(87, 13);
			this->label1->TabIndex = 4;
			this->label1->Text = L"N�mero palabras";
			// 
			// label2
			// 
			this->label2->AutoSize = true;
			this->label2->Location = System::Drawing::Point(3, 75);
			this->label2->Name = L"label2";
			this->label2->Size = System::Drawing::Size(100, 13);
			this->label2->TabIndex = 5;
			this->label2->Text = L"Nombre del Archivo";
			// 
			// Ejercicio2
			// 
			this->AutoScaleDimensions = System::Drawing::SizeF(6, 13);
			this->AutoScaleMode = System::Windows::Forms::AutoScaleMode::Font;
			this->ClientSize = System::Drawing::Size(311, 419);
			this->Controls->Add(this->label2);
			this->Controls->Add(this->label1);
			this->Controls->Add(this->dataGridView1);
			this->Controls->Add(this->button3);
			this->Controls->Add(this->button2);
			this->Controls->Add(this->button1);
			this->Name = L"Ejercicio2";
			this->Text = L"Ejercicio2";
			(cli::safe_cast<System::ComponentModel::ISupportInitialize^>(this->dataGridView1))->EndInit();
			this->ResumeLayout(false);
			this->PerformLayout();

		}
#pragma endregion
		array<String^>^ Find(array<String^>^ cadena_1) {
			cadena_1 = File::ReadAllLines(openFileDialog1->FileName);
			return cadena_1;
		}
		public: void add() {
			openFileDialog1->Filter = "Archivos separados por coma (csv) | *.csv";
			openFileDialog1->FileName = "";


			if (openFileDialog1->ShowDialog() == System::Windows::Forms::DialogResult::OK) {
				Reset();
				label2->Text = openFileDialog1->FileName;

				
				array<String^>^ lineaxlinea = File::ReadAllLines(openFileDialog1->FileName);
				label1->Text = Convert::ToString(lineaxlinea->Length);
				if (lineaxlinea->Length > 0) {

					
					array<String^>^ archivoColumna = lineaxlinea[0]->Split(',');
					if (archivoColumna->Length > 0) {
						int collcant = archivoColumna->Length;

						for (int i = 0; i < collcant; i++) {
							DataGridViewColumn^ newc = gcnew DataGridViewColumn();
							newc->Width = 50;
							DataGridViewCell^ cellTemplate = gcnew DataGridViewTextBoxCell();
							newc->CellTemplate = cellTemplate;
							dataGridView1->Columns->Add(newc);
						}


						for (int i = 0; i < (lineaxlinea->Length - 1); i++) {
							dataGridView1->Rows->Add();
						}

					
						for (int i = 0; i < lineaxlinea->Length; i++) {
							array<String^>^ fila = lineaxlinea[i]->Split(',');
							int y = 0;

						
							while ((y < collcant) && (y < fila->Length)) {
								dataGridView1->Rows[i]->Cells[y]->Value = fila[y];
								y++;
							}
						}
					}
				}

			}
			else {
				
				MessageBox::Show("Archivo no seleccionado"
					, "Archivo no seleccionado"
					, MessageBoxButtons::OK
					, MessageBoxIcon::Exclamation);
			}
		}
			  Boolean Palindroma(String^ p1) {
				  bool pal1 = true;
				  if (p1->Length > 1) {
					  if (p1[0] == p1[p1->Length - 1]) {
						  pal1 = true;
						  return Palindroma(p1->Substring(1, p1->Length - 2));
					  }
					  else {
						  pal1 = false;
						  return false;
					  }
				  }
				  else {
					  return true;
				  }
			  }
			  int pal_vec(array<String^>^ wordsplit, int magnitud, int o) {
				  wordsplit = wordsplit[o]->Split(',');
				  int contador;
				  for (int i = 0; i < (wordsplit->Length); i++) {
					  if (Palindroma(wordsplit[i]) == true) {
						  contador++;
					  }
				  }
				  return contador;
			  }
		private: void Reset() {
			dataGridView1->Rows->Clear();
			dataGridView1->Columns->Clear();
			dataGridView1->ColumnHeadersVisible = false;
			dataGridView1->RowHeadersVisible = false;
		}





	private: System::Void button1_Click(System::Object^ sender, System::EventArgs^ e) {
		add();
	}
private: System::Void button3_Click(System::Object^ sender, System::EventArgs^ e) {
	try {
		array<String^>^ wordsss;
		int most = 0;
		int conttot;
		wordsss = Find(wordsss);
		for (int i = 0; i < (wordsss->Length - 1); i++) {
			if (wordsss[i]->Length >= most) {
				most = wordsss[i]->Length;
			}
		}
		array<String^>^ Posandquant;
		for (int i = 0; i < (wordsss->Length); i++) {
			conttot += pal_vec(wordsss, most, i);
		}
		label1->Text = conttot + " palabras pal�ndromas";
	}
	catch (Exception^ e) {
		MessageBox::Show("Archivo no ingresado");
	}
}
private: System::Void button2_Click(System::Object^ sender, System::EventArgs^ e) {
	try {
		array<String^>^ wordsss;
		int most = 0;
		int conttot;
		wordsss = Find(wordsss);
		for (int i = 0; i < (wordsss->Length - 1); i++) {
			if (wordsss[i]->Length >= most) {
				most = wordsss[i]->Length;
			}
		}
		array<String^>^ Posandquant;
		for (int i = 0; i < (wordsss->Length); i++) {
			conttot += pal_vec(wordsss, most, i);
		}
		label1->Text = conttot + " palabras pal�ndromas";
	}
	catch (Exception^ e) {
		MessageBox::Show("Archivo no ingresado");
	}
}
};
}
