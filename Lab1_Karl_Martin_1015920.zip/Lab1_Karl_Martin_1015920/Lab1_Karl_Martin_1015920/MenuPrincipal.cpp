#include "MenuPrincipal.h"
using namespace Lab1KarlMartin1015920;
[STAThreadAttribute]
int main(array<String^>^ args) {
	Application::EnableVisualStyles();
	Application::SetCompatibleTextRenderingDefault(false);
	Lab1KarlMartin1015920::MenuPrincipal form;
	Application::Run(% form);
	return 0;
}
